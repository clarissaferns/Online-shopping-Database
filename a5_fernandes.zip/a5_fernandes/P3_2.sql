/*
-- Query 2

-- Produce a table of the products whose stock is below
-- 20 and the company that needs to restock them(output product id, company id, company name
-- and location who manufactured)

This query is useful so we check what
items are low on stock and contact the manufacturer company to send new stock.
*/

select product_id, m_id, company_name, location
from INVENTORY join MANUFACTURER
where (manufactured_in=company_name) and
(stock<20);

/* EXPECTED OUTPUT:
product_id  m_id        company_name  location
----------  ----------  ------------  ----------
5           M6          Denim Depot   Tokyo
6           M6          Denim Depot   Tokyo
14          M4          Skatez & Stu  Abu Dhabi
17          M4          Skatez & Stu  Abu Dhabi
23          M2          Bling!        New York

*/
