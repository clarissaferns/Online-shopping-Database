/*
-- Query 1

-- Produce a table consisting of the product id and names of
-- all products manufactured by Casa de Bruce

This query is useful so we can find all the products made by one manufacturer.
*/


select product_id,name
from INVENTORY
where manufactured_in='Casa de Bruce';

/* EXPECTED OUTPUT:
product_id  name
----------  --------------
8           Brown Cami Top
9           Black Heels
10          Red Heels
11          Red Cami Top
12          Pink Cami Top
13          Brown Velvet S
*/
