/*

-- Query 4

-- Produce a table consisting of the names and
-- userid of the person who shopped on the website on 20th march 2000

This query is useful so we can check who shopped when if there is anything wrong with the order.
OR if the customer wants to return something, we can check
when they shopped to see if its past the 14-day return policy.

*/

select username, user_id
from USERS join PURCHASES
where (user_id = u_id) and
(date_purchased='20-03-2000');

/* EXPECTED OUTPUT:
username      user_id
------------  ----------
Deanne Diego  U7

*/
