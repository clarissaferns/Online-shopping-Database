/*
-- Query 3

-- Produce a table that displays each manufacturer and
-- the number of products it provides to the store

This query is useful so we check which manufacturer is our most
top selling and we have the most products from.
*/

select manufactured_in, count(product_id)
from INVENTORY
group by manufactured_in;

/* EXPECTED OUTPUT:
manufactured_in  count(product_id)
---------------  -----------------
Bling!           5
Casa de Bruce    6
Clarissa & Co    4
Denim Depot      3
Hats by Heather  4
Skatez & Stuff   3
Sporty Galz Co   2
Watches by Rani  3

*/
