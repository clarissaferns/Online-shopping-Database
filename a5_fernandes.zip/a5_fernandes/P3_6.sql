/*

-- Query 6

-- Produce a table that shows the entire shopping bill of Clarissa Fernandes on 21st Feb, 2020

This query is useful to just track info of a customers bill.
*/

-- select prod_id, name, amt_purchased
-- from PURCHASE_HISTORY join INVENTORY
-- where (product_id=prod_id) and
-- ()

select name, prod_id, amt_purchased
from INVENTORY join(
  select prod_id, amt_purchased
  from PURCHASE_HISTORY join(
    select purchase_id
    from PURCHASES
    where date_purchased='21-02-2020')
  where (purchase_id=purchaseid))
where prod_id=product_id;

/* EXPECTED OUTPUT:
name           prod_id     amt_purchased
-------------  ----------  -------------
Pink Tank Top  4           3
Blue Distress  5           1
Silver Waist   23          4
*/
