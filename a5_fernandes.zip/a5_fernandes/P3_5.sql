/*

-- Query 5

-- Produce a table that lists all the purchases made by Deanne Diego.

This query is useful so we can check how often a customer shops and whether we can suggest
them a loyalty program or offer them a discount for being loyal to the store.

*/

select purchase_id, date_purchased
from PURCHASES
where (u_id='U7');

/* EXPECTED OUTPUT:
purchase_id  date_purchased
-----------  --------------
p2           20-03-2000
p6           24-03-2001
p7           28-02-2020    

*/
