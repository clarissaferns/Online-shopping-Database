
--NAME: CLARISSA FERNANDES
--101131520


--Making sure the tables are deleted in case script is run >1 time....
DROP TABLE IF EXISTS INVENTORY;
DROP TABLE IF EXISTS MANUFACTURER;
DROP TABLE IF EXISTS USERS;
DROP TABLE IF EXISTS PURCHASES;
DROP TABLE IF EXISTS PURCHASE_HISTORY;
--------------------------------------------------------------------------------
-- Creating the table INVENTORY....
CREATE TABLE INVENTORY
(
  product_id text not null,
  name text not null,
  stock integer not null,
  manufactured_in text not null,
  PRIMARY KEY(product_id)
);
--------------------------------------------------------------------------------
-- Creating the table MANUFACTERER....
CREATE TABLE MANUFACTURER
(
  m_id text not null,
  company_name text not null,
  location text not null,
  PRIMARY KEY(m_id)
);
--------------------------------------------------------------------------------
-- Creating the table USERS....
CREATE TABLE USERS
(
  user_id text not null,
  username text not null,
  password text not null,
  PRIMARY KEY(user_id)
);
--------------------------------------------------------------------------------
-- Creating the table PURCHASES....
CREATE TABLE PURCHASES(
  purchase_id text not null,
  u_id text not null,
  date_purchased text not null,
  PRIMARY KEY(u_id,purchase_id)
);
--------------------------------------------------------------------------------
-- Creating the table PURCHASE_HISTORY....
CREATE TABLE PURCHASE_HISTORY(
  purchaseid text not null,
  userid text not null,
  prod_id text not null,
  amt_purchased text not null,
  PRIMARY KEY(userid,purchaseid,prod_id)
);
--------------------------------------------------------------------------------
--Inserting values into INVENTORY TABLE...
INSERT INTO INVENTORY VALUES('1','Red Tank Top',50,'Clarissa & Co');
INSERT INTO INVENTORY VALUES('2','Black Tank Top',40,'Clarissa & Co');
INSERT INTO INVENTORY VALUES('3','Blue Tank Top',250,'Clarissa & Co');
INSERT INTO INVENTORY VALUES('4','Pink Tank Top',34,'Clarissa & Co');
INSERT INTO INVENTORY VALUES('5','Blue Distressed Jeans',12,'Denim Depot');
INSERT INTO INVENTORY VALUES('6','Black Distressed Jeans',5,'Denim Depot');
INSERT INTO INVENTORY VALUES('7','Beige Distressed Jeans',78,'Denim Depot');
INSERT INTO INVENTORY VALUES('8','Brown Cami Top',52,'Casa de Bruce');
INSERT INTO INVENTORY VALUES('9','Black Heels',57,'Casa de Bruce');
INSERT INTO INVENTORY VALUES('10','Red Heels',20,'Casa de Bruce');
INSERT INTO INVENTORY VALUES('11','Red Cami Top',30,'Casa de Bruce');
INSERT INTO INVENTORY VALUES('12','Pink Cami Top',40,'Casa de Bruce');
INSERT INTO INVENTORY VALUES('13','Brown Velvet Shawl',80,'Casa de Bruce');
INSERT INTO INVENTORY VALUES('14','Purple Velvet Shawl',7,'Skatez & Stuff');
INSERT INTO INVENTORY VALUES('15','Blue Sport Shoes',46,'Sporty Galz Co');
INSERT INTO INVENTORY VALUES('16','Pink and White Platform Shoes',124,'Sporty Galz Co');
INSERT INTO INVENTORY VALUES('17','Brown and Black Boots',6,'Skatez & Stuff');
INSERT INTO INVENTORY VALUES('18','Brown Leather Boots',984,'Skatez & Stuff');
INSERT INTO INVENTORY VALUES('19','Gold Link Chain',34,'Bling!');
INSERT INTO INVENTORY VALUES('20','Gold Choker',54,'Bling!');
INSERT INTO INVENTORY VALUES('21','Pearls with Pendant Choker',73,'Bling!');
INSERT INTO INVENTORY VALUES('22','Silver Link Bracelet',237,'Bling!');
INSERT INTO INVENTORY VALUES('23','Silver Waist chain',8,'Bling!');
INSERT INTO INVENTORY VALUES('24','Black Watch',23,'Watches by Rani');
INSERT INTO INVENTORY VALUES('25','Silver Butterfly Watch',73,'Watches by Rani');
INSERT INTO INVENTORY VALUES('26','Brown Leather band Watch',94,'Watches by Rani');
INSERT INTO INVENTORY VALUES('27','Red Beanie',235,'Hats by Heather');
INSERT INTO INVENTORY VALUES('28','Straw Hat',385,'Hats by Heather');
INSERT INTO INVENTORY VALUES('29','Tennis Cap',475,'Hats by Heather');
INSERT INTO INVENTORY VALUES('30','Baseball Cap',946,'Hats by Heather');
--------------------------------------------------------------------------------
--Inserting values into MANUFACTURER TABLE...
INSERT INTO MANUFACTURER VALUES('M1','Clarissa & Co','Los Angeles');
INSERT INTO MANUFACTURER VALUES('M2','Bling!','New York');
INSERT INTO MANUFACTURER VALUES('M3','Casa de Bruce','Mumbai');
INSERT INTO MANUFACTURER VALUES('M4','Skatez & Stuff','Abu Dhabi');
INSERT INTO MANUFACTURER VALUES('M5','Sporty Galz Co','Seoul');
INSERT INTO MANUFACTURER VALUES('M6','Denim Depot','Tokyo');
INSERT INTO MANUFACTURER VALUES('M7','Watches by Rani','Colombo');
INSERT INTO MANUFACTURER VALUES('M8','Hats by Heather','Ottawa');
--------------------------------------------------------------------------------
--Inserting values into USERS TABLE...
INSERT INTO USERS VALUES('U1','Clarissa Fernandes','1234');
INSERT INTO USERS VALUES('U2','Bruce Fernandes','akfgkejbf');
INSERT INTO USERS VALUES('U3','Rujuta Kumthekar','uvgh');
INSERT INTO USERS VALUES('U4','Kailash Balakrishnan','xucgci');
INSERT INTO USERS VALUES('U5','Sahil Agrawal','edibg');
INSERT INTO USERS VALUES('U6','Ranishka Fernando','oidjoic');
INSERT INTO USERS VALUES('U7','Deanne Diego','sldje');
INSERT INTO USERS VALUES('U8','Janita Himson','dx wqigdu');
INSERT INTO USERS VALUES('U9','Gloria Pritchett','quwbd dushbx');
INSERT INTO USERS VALUES('U10','Jay Pritchett','sjhbd hwbx');
INSERT INTO USERS VALUES('U11','Claire Dunphy','29187382');
INSERT INTO USERS VALUES('U12','Phil Dunphy','288378');
INSERT INTO USERS VALUES('U13','Luke Dunphy','653891');
INSERT INTO USERS VALUES('U14','Mitchell Pritchett','1283604');
INSERT INTO USERS VALUES('U15','Cameron Tucker','jasvc svge quwgd');
INSERT INTO USERS VALUES('U16','Lily Tucker-Pritchett','29387 3874y');
INSERT INTO USERS VALUES('U17','Manny Delgado','3hb4t42');
INSERT INTO USERS VALUES('U18','Haley Dunphy','5kj64bhug');
INSERT INTO USERS VALUES('U19','Dylan Marshall','12udhefd1234');
INSERT INTO USERS VALUES('U20','Pepper Saltzman','dewbde78y37y');
INSERT INTO USERS VALUES('U21','Levi Ackermann','hbhdjb89274');
INSERT INTO USERS VALUES('U22','Sasha Brauss','jsdbhw1038783');
--------------------------------------------------------------------------------
--Inserting values into PURCHASES TABLE...
INSERT INTO PURCHASES VALUES('p1','U1','21-02-2020');
INSERT INTO PURCHASES VALUES('p2','U7','20-03-2000');
INSERT INTO PURCHASES VALUES('p3','U2','01-04-2019');
INSERT INTO PURCHASES VALUES('p4','U8','20-04-2019');
INSERT INTO PURCHASES VALUES('p5','U15','02-03-2021');
INSERT INTO PURCHASES VALUES('p6','U7','24-03-2001');
INSERT INTO PURCHASES VALUES('p7','U7','28-02-2020');
--------------------------------------------------------------------------------
--Inserting values into PURCHASE_HISTORY...
INSERT INTO PURCHASE_HISTORY VALUES('p1','U1','4','3');
INSERT INTO PURCHASE_HISTORY VALUES('p1','U1','5','1');
INSERT INTO PURCHASE_HISTORY VALUES('p1','U1','23','4');
INSERT INTO PURCHASE_HISTORY VALUES('p2','U7','25','5');
INSERT INTO PURCHASE_HISTORY VALUES('p2','U7','19','1');
INSERT INTO PURCHASE_HISTORY VALUES('p2','U7','22','2');
INSERT INTO PURCHASE_HISTORY VALUES('p4','U8','30','5');
INSERT INTO PURCHASE_HISTORY VALUES('p4','U8','12','3');
INSERT INTO PURCHASE_HISTORY VALUES('p4','U8','1','1');
INSERT INTO PURCHASE_HISTORY VALUES('p5','U15','25','7');
INSERT INTO PURCHASE_HISTORY VALUES('p5','U15','18','2');
INSERT INTO PURCHASE_HISTORY VALUES('p5','U15','5','3');
INSERT INTO PURCHASE_HISTORY VALUES('p3','U2','30','1');
INSERT INTO PURCHASE_HISTORY VALUES('p3','U2','21','4');
INSERT INTO PURCHASE_HISTORY VALUES('p6','U7','17','5');
INSERT INTO PURCHASE_HISTORY VALUES('p6','U7','18','1');
INSERT INTO PURCHASE_HISTORY VALUES('p7','U7','13','2');
INSERT INTO PURCHASE_HISTORY VALUES('p7','U7','20','4');
